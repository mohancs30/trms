<?php
use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
/* @var $this yii\web\View */
/* @var $searchModel app\models\BookingSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$this->title = 'Bookings';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="booking-index">	
    <h1><?= Html::encode($this->title) ?></h1>
   	<?= $this->render('_form', ['model' => $model,]) ?>
	<?php // echo $this->render('_search', ['model' => $searchModel]); ?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'B_id',
            'Movetype',
            'Qty',
            'Arrivaltime',
            'status',
            'Remarks',
            //'C_date',
            //'C_By',
            //'M_date',
            //'M_By',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
