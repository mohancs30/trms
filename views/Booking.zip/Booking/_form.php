<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Mstvehicle;
use kartik\select2\Select2;
use kartik\datecontrol\DateControl;
use app\models\Mstcompany;
use app\models\Booking;
use app\models\Mstgroupcode;
use kartik\date\DatePicker;
use yii\helpers\CONSTANT;
/* @var $this yii\web\View */
/* @var $model app\models\Booking */
/* @var $form yii\widgets\ActiveForm */
?>
<head>
<style>

 .card-body {
     -ms-flex: 1 1 auto;
     flex: 1 1 auto;
     padding: 1.40rem
 }

 .img-sm {
     width: 150px;
     height: 100px
 }

 .itemside .info {
     padding-left: 15px;
     padding-right: 7px
 }

 .table-shopping-cart .price-wrap {
     line-height: 1.2
 }

 .table-shopping-cart .price {
     font-weight: bold;
     margin-right: 5px;
     display: block
 }

 .text-muted {
     color: #969696 !important
 }

 a {
     text-decoration: none !important
 }

 .card {
     position: relative;
     display: -ms-flexbox;
     display: flex;
     -ms-flex-direction: column;
     flex-direction: column;
     min-width: 0;
     word-wrap: break-word;
     background-color: #fff;
     background-clip: border-box;
     border: 1px solid rgba(0, 0, 0, .125);
     border-radius: 0px
 }

 .itemside {
     position: relative;
     display: -webkit-box;
     display: -ms-flexbox;
     display: flex;
     width: 100%
 }

 .dlist-align {
     display: -webkit-box;
     display: -ms-flexbox;
     display: flex
 }

 [class*="dlist-"] {
     margin-bottom: 5px
 }

 .coupon {
     border-radius: 1px
 }

 .price {
     font-weight: 600;
     color: #212529
 }

 .btn.btn-out {
     outline: 1px solid #fff;
     outline-offset: -5px
 }

 .btn-main {
     border-radius: 2px;
     text-transform: capitalize;
     font-size: 15px;
     padding: 10px 19px;
     cursor: pointer;
     color: #fff;
     width: 100%
 }

 .btn-light {
     color: #ffffff;
     background-color: #F44336;
     border-color: #f8f9fa;
     font-size: 12px
 }

 .btn-light:hover {
     color: #ffffff;
     background-color: #F44336;
     border-color: #F44336
 }

 .btn-apply {
     font-size: 11px
 }
 
</style>


</head>
<div class="card-box">
	<div class="booking-form">
		<?php $form = ActiveForm::begin(['action' => ['booking/create']]);
		//$leadsCount = mstvehicle::find()->where(['and','status = "A"','vehicleType="TR"'])->count();
		//print_r($modelvehicle);
		?>
		<?php $modelvehicle =new Mstvehicle(); ?>
		<?php $modelvehicle1 =new Mstvehicle(); ?>
		<?php $model1 =new Booking(); ?>
		
		<div class="row">
			
	<div class="container-fluid">
   
        <aside class="col-lg-9">
            <div class="card">
                <div class="table-responsive">
                    <table class="table table-borderless  table-shopping-cart">
                     
                            <tr class="small text-uppercase">
                                <th scope="col">Vehicles</th>
								<th scope="col">Booking Type</th>
								<th scope="col">Size</th>
								<th scope="col">Type</th>
								<th scope="col">Available</th>
                                <th scope="col" width="0">Quantity</th>
                                
								
                            </tr>
                      
                        <tbody>
                            <tr>
                                <td>
                                    <figure class="itemside align-items-center">
                                        <div class="aside"><img src="images/Trailer.png" class="img-sm"></div>
                                      <!--  <figcaption class="info"> <a href="#" class="title text-dark" data-abc="true">Trailer </a>
                                            
                                        </figcaption>-->
                                    </figure>
                                </td>
								
								 <td>	
                                 <?=  
								$form->field($model, 'Movetype')->widget(Select2::classname(), [
								'data' => ['collection' => 'collection', 'return' => 'return'],
								'theme' => Select2::THEME_CLASSIC,
								'language' => 'en',
								'options' => ['placeholder' => 'Size ...'],
								'pluginOptions' => [
								'allowClear' => true   ],
								]);
								?>
								</td>
							
                                 <td>	
                                    <?=   $form->field($modelvehicle, 'Size')->widget(Select2::classname(), [
										'data' =>ArrayHelper::map(Mstvehicle::find()-> where (['VehicleType'=>'TR'])->all(),'Size','Size'), 
										'theme' => Select2::THEME_CLASSIC,
										'language' => 'en',
										'options' => ['placeholder' => 'Size ...'],
										'pluginOptions' => [
										'allowClear' => true   ],
										]); 
									?>
								</td>
                                <td>
										
                                         <?=   $form->field($modelvehicle, 'VehicleDesc')->widget(Select2::classname(), [
										'data' =>ArrayHelper::map(Mstvehicle::find()->where (['VehicleType'=>'TR'])->all(),'VehicleDesc','VehicleDesc'), 
										'theme' => Select2::THEME_CLASSIC,
										'language' => 'en',
										'options' => ['placeholder' => 'Type ...'],
										'pluginOptions' => [
										'allowClear' => true   ],
										]); 
									?>
                                </td>
								 <td  style="color:green;font-size:x-large">
								 
								 	<input type='text' id='avltrailer' disabled>
									
								 </td>
                                <td>
							
									<?=$form->field($model, 'Qty', [
									'options' => [
                                    'tag' => 'div',
                                    'class' => '',
									],
                                   'template' => '<span class="col-md-8 col-lg-8">{input}{error}</span>'
									])->textInput([
                                   'type' => 'text',
								   'value' => '',
									])->label(false)?>


								</td>
								
                            </tr>
										
						
							
							
						    <tr>
                                <td>
                                    <figure class="itemside align-items-center">
                                        <div class="aside"><img src="images/Pm.png" class="img-sm" id="imgtr"></div>
                                        <!--<figcaption class="info"> <a href="#" class="title text-dark" data-abc="true">Prime Mover</a>
                                            <p class="text-muted small"> <br> </p>
                                        </figcaption>-->
                                    </figure>
                                </td>
                                <td>	
                                 <?=  
								$form->field($model1, 'Movetype')->widget(Select2::classname(), [
								'data' => ['collection' => 'collection', 'return' => 'return'],
								'theme' => Select2::THEME_CLASSIC,
								'language' => 'en',
								'options' => ['placeholder' => 'Size ...'],
								'pluginOptions' => [
								'allowClear' => true   ],
								]);
								?>
								</td>
							
                                 <td>	
                                    <?=   $form->field($modelvehicle1, 'Size')->widget(Select2::classname(), [
										'data' =>ArrayHelper::map(Mstvehicle::find()-> where (['VehicleType'=>'PM'])->all(),'Size','Size'), 
										'theme' => Select2::THEME_CLASSIC,
										'language' => 'en',
										'options' => ['placeholder' => 'Size ...'],
										'pluginOptions' => [
										'allowClear' => true   ],
										]); 
									?>
								</td>
                                <td>
										
                                         <?=   $form->field($modelvehicle1, 'VehicleDesc')->widget(Select2::classname(), [
										'data' =>ArrayHelper::map(Mstvehicle::find()->where (['VehicleType'=>'PM'])->all(),'VehicleDesc','VehicleDesc'), 
										'theme' => Select2::THEME_CLASSIC,
										'language' => 'en',
										'options' => ['placeholder' => 'Type ...'],
										'pluginOptions' => [
										'allowClear' => true   ],
										]); 
									?>
                                </td>
								 <td  style="color:green;font-size:x-large">
								 
								 	<input type='text' id='avltrailer' disabled>
									
								 </td>
                                <td>
							
									<?=$form->field($model, 'Qty', [
									'options' => [
                                    'tag' => 'div',
                                    'class' => '',
									],
                                   'template' => '<span class="col-md-8 col-lg-8">{input}{error}</span>'
									])->textInput([
                                   'type' => 'text',
								   'value' => '',
									])->label(false)?>


								</td>
                                <td class="text-right d-none d-md-block">
								
								
								</td>
								
                            </tr>
							
                           
                        </tbody>
                    </table>
					
					
				
				<div class="card" id='result'>
								<table id="records_table" border='1' style="overflow: scroll; ">
								<tr>
									<th>
									<input type="checkbox" id="selectAll" />
									</th>
									<th>VehicleRegNo</th>
									<th>VehicleType</th>
									<th>Size</th>
									<th>VehicleDesc</th>
									<th>LadenWight</th>
									<th>UnLadenWight</th>
								</tr>
								</table>
							</div>
							


					<div class="col-md-4 col-sm-3"> 
						
							
							<?php echo  $form->field ( $model , 'Fromdate' )->widget ( DatePicker::className () , [
							'options' => [ 'placeholder' => 'Select date ...' ] ,
							'pluginOptions' => [
							   'format' => 'dd-mm-yyyy' ,
							   'autoclose' => true,
							   'todayHighlight' => true
							]
						] )->label ( 'From date' );
						?>
							
						
				    </div> 
					
					<div class="col-md-4 col-sm-3"> 
						
							
							<?php echo  $form->field ( $model , 'Todate' )->widget ( DatePicker::className () , [
							'options' => [ 'placeholder' => 'Select date ...' ] ,
							'pluginOptions' => [
							   'format' => 'dd-mm-yyyy' ,
							   'autoclose' => true,
							   'todayHighlight' => true
							]
						] )->label ( 'To date' );
						?>
							
						
				    </div> 
						
						
                </div>
            </div>
        </aside>
        <aside class="col-lg-3">
           
            <div class="card">
                <div class="card-body">
                    <dl class="dlist-align">
                        <dt>Total price:</dt>
                        <dd class="text-right ml-3">$69.97</dd>
                    </dl>
                    <dl class="dlist-align">
                        <dt>Discount:</dt>
                        <dd class="text-right text-danger ml-3">- $10.00</dd>
                    </dl>
                    <dl class="dlist-align">
                        <dt>Total:</dt>
                        <dd class="text-right text-dark b ml-3"><strong>$59.97</strong></dd>
                    </dl>
                    <!--<hr><a href="#" class="btn btn-out btn-success btn-square btn-main mt-2" data-abc="true">Book</a>-->
                </div>
            </div>
        </aside>

	</div>
		</div>

		
			<div class="row">				   
			<div class="col-lg-6">
				<div class="mt-5">
					 <div class="mb-6">
						<div class="form-group">
							<?= Html::submitButton('Book', ['class' => 'btn btn-success btn-lg']) ?>
						</div>
						<?php ActiveForm::end(); ?>
					</div>
				</div>
			</div>
			</div>
		</div>					
	</div>
	
	
	
<?php
$script = <<< JS
$( document ).ready(function() {
	
$("#records_table tr").hide();

$('#selectAll').click(function (e) {
    $(this).closest('table').find('td input:checkbox').prop('checked', this.checked);
});
	$("#mstvehicle-vehicledesc").on('change', function(ev){
	ev.preventDefault();
	var size=$("#mstvehicle-size").val();
	if (size==''){
		
		alert('please select size');
		
	}
	var type=$("#mstvehicle-vehicledesc").val();
	var avlqty=parseInt($('#avltrailer').val());
	var reqqty =parseInt($('#booking-qty').val());
	
	if(size!='' ){ 
	 jQuery.ajax({
                'type':'POST',
				'dataType':'json',
                'url':'index.php?r=booking/getavltrailer',
                'cache':false,
                'data':{size:size,type:type},
                success:function(data)
                {
				var len = data.length;
				for(var i=0; i<len; i++){
					var id = data[i].travl;
				   
				}
					  $('#avltrailer').val(id);
					  $("#avltrailer").attr("value",id);
					 
                }
				
            });
	}		
			
    });
		
	$("#mstvehicle-size").on('change', function(ev){
	ev.preventDefault();
	
	if(reqqty > avlqty){
		
	alert('Available trailers -   ' + avlqty + ' ');
	
	}	
	var size=$("#mstvehicle-size").val();
	var type=$("#mstvehicle-vehicledesc").val();
	var avlqty=parseInt($('#avltrailer').val());
	var reqqty =parseInt($('#booking-qty').val());
	if(reqqty!=''&& reqqty < avlqty){
		
				jQuery.ajax({
                'type':'POST',
				'dataType':'json',
                'url':'index.php?r=booking/getlist',
                'cache':false,
                'data':{size:size,type:type,avlqty:avlqty,reqqty:reqqty},
                success:function(data)
                {
					$("#records_table tr").show();
					$("#records_table td").detach();
					var trHTML = '';
              				
				$.each(data, function(i, item){
					
					var length= data.length;
					trHTML += '<tr><td><input type="checkbox" id='+item.VehicleRegNo+' value='+item.VehicleRegNo+'/></td><td>' + item.VehicleRegNo + '</td><td>' + item.VehicleType + '</td><td>' + item.Size + '</td><td>'+item.VehicleDesc+'</td><td>'+item.LadenWight+'</td><td>'+item.UnLadenWight+'</td></tr>';
					 
				});
					$('#records_table').append(trHTML);
				}
				});
			
	}else{
		
		
	}

	if(size!='' ){
	 jQuery.ajax({
                'type':'POST',
				'dataType':'json',
                'url':'index.php?r=booking/getavltrailer',
                'cache':false,
                'data':{size:size,type:type},
                success:function(data)
                {
				var len = data.length;
				for(var i=0; i<len; i++){
				var id = data[i].travl;
				   
				}	
					  $('#avltrailer').val(id);
					  $("#avltrailer").attr("value",id);
					 
                }
				
            });
	}
	
    });
	
	$("#booking-qty").on('change', function(ev){
	ev.preventDefault();
	var size=$("#mstvehicle-size").val();
	if (size==''){
		
		alert('please select size');
		
	}
	var type=$("#mstvehicle-vehicledesc").val();
	var avlqty=parseInt($('#avltrailer').val());
	var reqqty =parseInt($('#booking-qty').val());
	
    if(reqqty > avlqty){
		
	alert('Available trailers -   ' + avlqty + ' ');
	
	}
	if(size && reqqty && size!='' && reqqty < avlqty){
		 jQuery.ajax({
                'type':'POST',
				'dataType':'json',
                'url':'index.php?r=booking/getlist',
                'cache':false,
                'data':{size:size,type:type,avlqty:avlqty,reqqty:reqqty},
                success:function(data)
                {
					
					$("#records_table tr").show();
					$("#records_table td").detach();
					
					var trHTML = '';
              				
				$.each(data, function(i, item){
					
					var length= data.length;
				
					trHTML += '<tr><td><input type="checkbox" id='+item.VehicleRegNo+' value='+item.VehicleRegNo+'/></td><td>' + item.VehicleRegNo + '</td><td>' + item.VehicleType + '</td><td>' + item.Size + '</td><td>'+item.VehicleDesc+'</td><td>'+item.LadenWight+'</td><td>'+item.UnLadenWight+'</td></tr>';
					 
				});
					
					 $('#records_table').append(trHTML);
				}
				});
	
			
				   
				}	
                  
                
              
			else{
		 	 
				alert('check your inputs');
		 
		}
	
		});
	});

JS;
$this->registerJs($script);
?>
